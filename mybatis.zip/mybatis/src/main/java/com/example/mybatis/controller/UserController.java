
package com.example.mybatis.controller;


import com.alibaba.fastjson.JSONObject;
import com.example.mybatis.entity.Travel;
import com.example.mybatis.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@ComponentScan({"com.example.mybatis.service"})
public class UserController {
    @Autowired
    UserService userService;

    @GetMapping("user")
    @ResponseBody
    public JSONObject getUser(){
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data",userService.find());
        return jsonObject;
    }

    @GetMapping("getTravel")
    @ResponseBody
    public JSONObject getTravel(){
        JSONObject result = new JSONObject();
        result.put("data",userService.getTravel());
        return result;
    }

    @PostMapping("setTravel")
    @ResponseBody
    public JSONObject setTravel(Travel travel){
        JSONObject result = new JSONObject();
        userService.insert(travel);
        result.put("code",1);
        return result;
    }

    @RequestMapping("travel")
    public String travel(){
        return "travel";
    }

    @GetMapping("getOneTravel")
    @ResponseBody
    public JSONObject getOneTravel(String name){
        JSONObject result = new JSONObject();
        Travel travel = userService.getTravelOne(name);
        result.put("data",travel);
        if(travel == null){
            result.put("code",0);
            return result;
        }
        if(travel.getIsTravel()==0){
            result.put("code",1);
            return result;
        }
        result.put("code",1);
        //result.put("data",travel);
        return result;
    }
}
