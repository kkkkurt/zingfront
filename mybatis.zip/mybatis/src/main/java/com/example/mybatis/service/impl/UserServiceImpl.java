
package com.example.mybatis.service.impl;

import com.example.mybatis.entity.Travel;
import com.example.mybatis.entity.User;
import com.example.mybatis.mapper.UserMapper;
import com.example.mybatis.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import java.util.List;

@ComponentScan({"com.example.mybatis.mapper"})
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

  /*  @Override
    public void insert(User user) {
        userMapper.insert(user);
    }*/

   /* public void update(User user) {
        userMapper.update(user);
    }
*/
    public List<User> find() {
        return userMapper.find();
    }

    @Override
    public List<Travel> getTravel() {
        return userMapper.getTravel();
    }

    @Override
    public void insert(Travel travel) {
        userMapper.insert(travel);
    }

    @Override
    public Travel getTravelOne(String name) {
        return userMapper.getTravelOne(name);
    }

   /* public void delete(int id){
        userMapper.delete(id);
    }*/
}
