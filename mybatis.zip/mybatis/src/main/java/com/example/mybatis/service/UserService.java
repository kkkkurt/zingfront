
package com.example.mybatis.service;

import com.example.mybatis.entity.Travel;
import com.example.mybatis.entity.User;

import java.util.List;

public interface UserService {

   /* void insert(User user);

    void update(User user);*/

    List<User> find();

  /*  void delete(int id);*/

    List<Travel> getTravel();

    void insert(Travel travel);

    Travel getTravelOne(String name);
}
