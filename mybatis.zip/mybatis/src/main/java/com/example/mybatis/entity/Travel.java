package com.example.mybatis.entity;

/**
 * 旅游实体类
 */
public class Travel {

    private String location;
    private String note;
    private Integer isTravel;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getIsTravel() {
        return isTravel;
    }

    public void setIsTravel(Integer isTravel) {
        this.isTravel = isTravel;
    }

}
