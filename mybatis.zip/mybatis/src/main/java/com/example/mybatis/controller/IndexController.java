package com.example.mybatis.controller;

import org.apache.poi.xwpf.converter.core.BasicURIResolver;
import org.apache.poi.xwpf.converter.core.FileImageExtractor;
import org.apache.poi.xwpf.converter.xhtml.XHTMLConverter;
import org.apache.poi.xwpf.converter.xhtml.XHTMLOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.UUID;

@Controller
public class IndexController {
    @RequestMapping("index")
    public String index(){
        return "index";
    }


    @RequestMapping("test")
    public String test(){
        return "test";
    }

    @PostMapping("/upload")
    public static String upload(MultipartFile fileUpload) throws Exception{
        //获取文件名
        String fileName = fileUpload.getOriginalFilename();
        //获取文件后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        //重新生成文件名
        fileName = UUID.randomUUID()+suffixName;
        String path2 = System.getProperty("user.dir");
        //String path1 = ClassUtils.getDefaultClassLoader().getResource("").getPath();
        try {
            //指定本地文件夹存储图片
            String filePath = path2 + "\\src\\main\\resources\\static\\";


            try {
                //将图片保存到static文件夹里
                fileUpload.transferTo(new File(filePath + fileName));
                //return new Massage(0,"success to upload");
            } catch (Exception e) {
                e.printStackTrace();
                //return new Massage(-1,"fail to upload");
            }


            //public static void PoiWord07ToHtml (HttpServletRequest request) throws IOException{

            String path = filePath;
            String file = filePath + fileName;
            //String file2 ="C:\\Users\\Administrator\\Desktop\\word07.html";
            String file2 = path2 + "\\src\\main\\resources\\templates\\" + "word.html";

            File f = new File(file);
            if (!f.exists()) {
                System.out.println("Sorry File does not Exists!");
            } else {
                if (f.getName().endsWith(".docx") || f.getName().endsWith(".DOCX")) {
                    //读取文档内容
                    InputStream in = new FileInputStream(f);
                    XWPFDocument document = new XWPFDocument(in);

                    File imageFolderFile = new File(path);
                    //加载html页面时图片路径
                    XHTMLOptions options = XHTMLOptions.create().URIResolver(new BasicURIResolver("./"));
                    //图片保存文件夹路径
                    options.setExtractor(new FileImageExtractor(imageFolderFile));
                    OutputStream out = new FileOutputStream(new File(file2));
                    XHTMLConverter.getInstance().convert(document, out, options);
                    out.close();
                } else {
                    System.out.println("Enter only MS Office 2007+ files");
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return "word";

    }
}
