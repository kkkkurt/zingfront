
package com.example.mybatis.mapper;

import com.example.mybatis.entity.Travel;
import com.example.mybatis.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface UserMapper {

    /*void insert(User user);

    void update(User user);

    void delete(int id);*/

    List<User> find();

    List<Travel> getTravel();

    void insert(Travel travel);

    Travel getTravelOne(String name);
}
