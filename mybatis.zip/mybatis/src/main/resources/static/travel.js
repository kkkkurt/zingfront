$(function(){
// do something
    //var tmp = {};
    $.ajax({
        type:"GET",
        url:"../getTravel",
        dataType:"json",
        success:function(data){
            var data1 = data.data;
            console.log(data1)
            var tmp;
            var result = [];
            for(var i =0;i<data1.length;i=i+1){
                tmp = {};
                tmp={name:data1[i].location,value:data1[i].note,selected:true};
                console.log(tmp);
                result.push(tmp);
            }
            console.log(result);

            var dom = document.getElementById("main");
            var myChart = echarts.init(dom);
            var app = {};
            option = null;
            option = {
                title : {
                    text: '旅游备忘录',
                    left: 'center'
                },
                tooltip : {
                    trigger: 'item',
                    formatter: function(params) {
                        var res = params.name+'<br/>';
                        var myseries = option.series;
                        for (var i = 0; i < myseries.length; i++) {
                            for(var j=0;j<myseries[i].data.length;j++){
                                if(myseries[i].data[j].name==params.name){
                                    res+=myseries[i].name +' : '+myseries[i].data[j].value+'</br>';
                                }
                            }
                        }
                        return res;
                    }
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    data:['plan']
                },
                visualMap: {
                   show:false,//不显示也有颜色区分的效果
                   min: 0,
                   max: 50000,
                   left: 'left',
                   top: 'bottom',
                     text: ['高','低'], // 文本，默认为数值文本
                     calculable: false,//是否显示可拖动的句柄
                     inRange: {
                            color: ['rgba(15,220,150,.5)','#00415a',]
                     }
                },
                toolbox: {
                    show: true,
                    orient : 'vertical',
                    left: 'right',
                    top: 'center',
                    feature : {
                        mark : {show: true},
                        dataView : {show: true, readOnly: false},
                        restore : {show: true},
                        saveAsImage : {show: true}
                    }
                },
                series : [
                    {
                        name: 'plan',
                        type: 'map',
                        mapType: 'china',
                        roam: false,
                        label: {
                            normal: {
                                show: false
                            },
                            emphasis: {
                                show: true
                            }
                        },
                        data:result
                    }
                ]
            };;
            if (option && typeof option === "object") {
                myChart.setOption(option, true);
                myChart.on('click', function(params){
                    window.localStorage.setItem("location",params.name);
                    $.ajax({
                        type: "GET",
                        url: "../getOneTravel",
                        data:{"name":params.name},
                        dataType: "json",
                        success: function (data) {
                            console.log(data);
                            if(data.code == 1){
                                layer.alert('你去过那儿了', {icon: 6});
                            }else{
                                layer.open({
                                    type: 1,
                                    title:'计划',
                                    skin:'layui-layer-rim',
                                    area:['450px', 'auto'],
                                    content:'<div id="mydiv"  style="margin-left:35px;margin-top:25px;"><textarea id="Context" style="width:430px;height:210px;resize:none;border-radius:6px;" ></textarea></div>',

                                    btn:['保存','取消'],
                                    btn1: function (index,layero) {
                                        var closeContext=top.$('#Context').val();
                                        debugger
                                        var name = window.localStorage.getItem("location");
                                        $.ajax({
                                            type: "post",
                                            url: "../setTravel",
                                            data:{"location":params.name,"note":closeContext,"isTravel":1},
                                            dataType: "json",
                                            success: function (data){
                                                window.location.reload();
                                                window.localStorage.clear();
                                            }

                                        });

                                        console.log(name);
                                    },
                                    btn2:function (index,layero) {
                                        layer.close(index);
                                    }

                                });
                            }
                        }
                    });
                });
            }
        },
        error:function(){

        }
    });

});