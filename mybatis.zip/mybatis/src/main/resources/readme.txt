说明：


web项目用springboot框架做的，

web第一题使用springboot poi
思路是吧word文档上传到服务端，然后转换为html

web第二题使用的后端mysql+mybatis+springboot 前端使用：layer.js 和echarts