package question1;

public class MainTest {

	public static void main(String[] args) {
        StringCompare stringCompare = new StringCompare();
        String s="This is C programming text";
        String t="This is a text for C programming";
        
        //stringCompare.stringCompare(s, t);
        //stringCompare.stringCompare(s, "");
        stringCompare.stringCompare("hello my lovely interviewer", "I am kkkurt");
        //stringCompare.stringCompare(s, null);
	}

}
